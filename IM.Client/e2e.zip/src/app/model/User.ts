export class User {
    UserName: String;
    Passowrd: String;
    firstName: String;
    lastName: String;
    email: String;
    contractNo: String;
    dateofbirth:Date;
}