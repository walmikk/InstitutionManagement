export class Student {
    first_Name: String;
    last_Name: String;
    email: String;
    phone: String;
}